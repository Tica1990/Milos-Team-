import asyncio
import json
import unittest
from milos_integration import parse_plan, run_milos_team


class IntegrationTests(unittest.IsolatedAsyncioTestCase):
    def test_parse_plan(self):
        self.assertEqual(parse_plan('```json\n{"assignments":{"Scout":"Research"}}\n```'), {'Scout': 'Research'})
        with self.assertRaises(ValueError):
            parse_plan('{"assignments":{"Unknown":"Hello"}}')
        with self.assertRaises(ValueError):
            parse_plan('{"assignments":{},"extra":true}')

    async def test_milos_plans_delegates_and_synthesizes(self):
        calls = []
        async def planner(goal):
            calls.append('plan')
            return json.dumps({'assignments': {'Scout': 'Find data', 'Milorad': 'Check law'}})
        async def runner(item, prompt, delegate, turns):
            calls.append(item.agent)
            if item.agent == 'Scout':
                reply = await delegate(item, 'Mirjana', 'Evaluate the data')
                return 'Scout: ' + reply
            return item.agent + ' done'
        async def synthesizer(goal, assignments, result):
            calls.append('synthesis')
            return f"Reviewed {result['agent_runs']} runs"
        result = await run_milos_team('Test goal', planner=planner, specialist_runner=runner, synthesizer=synthesizer)
        self.assertEqual(result['status'], 'COMPLETED')
        self.assertEqual(result['agent_runs'], 3)
        self.assertEqual(result['delegations'], 1)
        self.assertIn('Mirjana', calls)
        self.assertEqual(result['milos_summary'], 'Reviewed 3 runs')
        self.assertEqual(calls[-1], 'synthesis')


if __name__ == '__main__':
    unittest.main()
