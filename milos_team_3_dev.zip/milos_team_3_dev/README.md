# Miloš Team 3.0 – isolierter Entwicklungsprototyp

Dieser Prototyp ist **nicht** in `main` integriert und ändert die bestehende Render-Version nicht.

## Funktion
- Spezialisten mit unabhängigen Aufgaben laufen parallel via `asyncio.gather`.
- Abhängige Aufgaben starten erst nach vollständiger Übergabe der benötigten Ergebnisse.
- Status-Events zeigen tatsächliche Starts, Abschlüsse und Fehler.
- Maximale Parallelität ist begrenzt; Fehler werden pro Agent erfasst.

## Beispiel
```python
from parallel_team import Task, run_parallel_team

result = await run_parallel_team(
    "Bewerte die Gründung eines arbeitsmedizinischen Dienstes",
    [
        Task("Scout", "Recherchiere Markt und Konkurrenz"),
        Task("Milorad", "Prüfe rechtliche Rahmenbedingungen"),
        Task("Doktor Mladen", "Prüfe medizinische Umsetzbarkeit"),
        Task("Mirjana", "Bewerte Wirtschaftlichkeit anhand der Recherche", ["Scout"]),
        Task("Pinky", "Erstelle einen Pilotplan", ["Mirjana", "Milorad", "Doktor Mladen"]),
    ],
)
```

## Noch offen vor Produktivbetrieb
- Autonome Agentenplanung und direkte dynamische Rückfragen untereinander
- Maximal eine Konflikt-/Debattenrunde
- Persistente Events und Wiederaufnahme nach Render-Neustart
- Freigabe-/Nutzerwarte-Status mit Fortsetzung
- Kosten-/Timeout-Limits, Tests, separater Render-Testservice

**Sicherheit:** Dieser Prototyp bietet nur parallele Ausführung und explizite Ergebnisübergaben, noch keine vollständig freie Agent-zu-Agent-Kommunikation. Keine Änderungen an der bestehenden `app.py` oder `team.py`.

## Neue Architektur: direkte Agent-zu-Agent-Kommunikation

`autonomous_team.py` enthält eine isolierte `Coordinator`-Implementierung:

- Jeder Spezialist kann mit dem Laufzeit-Tool `frage_kollege(ziel_agent, auftrag)` selbstständig andere Spezialisten konsultieren.
- Unabhängige Ausgangsaufträge laufen parallel; abhängige Antworten werden direkt an den anfragenden Spezialisten zurückgegeben.
- Miloš wird als übergeordneter Auftraggeber/Orchestrator in einer späteren Integration ergänzt; der vorliegende Prototyp nimmt explizite Ausgangsaufträge entgegen.
- Grenzen für Anzahl der Agentenläufe, Delegationen, Delegationstiefe, parallele Root-Aufträge und Gesamtlaufzeit.
- Protokollierung der tatsächlich stattgefundenen Starts, Nachrichten, Abschlüsse und Fehler.
- Keine externen Schreib-/Versand-/Kaufaktionen.

### Beispiel (separate Entwicklungsumgebung)

```python
from autonomous_team import run_autonomous_team

result = await run_autonomous_team(
    "Bewerte die Gründung eines arbeitsmedizinischen Dienstes",
    {
        "Scout": "Recherchiere Markt und Konkurrenz",
        "Milorad": "Prüfe die rechtlichen Rahmenbedingungen",
        "Doktor Mladen": "Prüfe die medizinische Umsetzbarkeit",
    },
)
```

### Tests

```sh
python -m unittest -v test_autonomous_team.py
```

### Wichtige Grenzen dieses Stands

- `team.py` aus dem bestehenden Repository und die installierte Version von `openai-agents` sind für Live-Tests nötig; `Agent.clone()` muss mit der dortigen SDK-Version verifiziert werden.
- Es gibt noch keine Miloš-Planung aus freiem Nutzertext, keine Debattenrunde, keine dauerhafte Queue, keine Fortsetzung nach Neustart und keine vollständige Kostenkontrolle.
- Der Koordinator begrenzt parallele Root-Aufträge, nicht die Gesamtzahl gleichzeitig aktiver verschachtelter Agenten. Ein striktes globales Concurrency-Limit braucht eine nicht-blockierende Task-Queue.
- Ein separater Render-Testservice und echte Integrationstests stehen aus.
- GitHub-Schreibzugriff war zuletzt durch 403 blockiert. Es wurde nichts in `main` geändert.

## Miloš-Integration (neu)

`milos_integration.py` ergänzt einen eigenständigen Ablauf:

1. Miloš erstellt ein validiertes JSON mit 1–4 unabhängigen Erstaufträgen.
2. `Coordinator` startet die Spezialisten parallel; sie dürfen über `frage_kollege` selbstständig weitere Spezialisten beauftragen.
3. Miloš erhält die tatsächlichen Ergebnisse und formuliert die abschließende Synthese.

Beispiel für einen **separaten Testprozess** (mit installiertem SDK, `team.py` und gesetztem `OPENAI_API_KEY`):

```python
import asyncio
from milos_integration import run_milos_team

async def main():
    result = await run_milos_team('Prüfe ein Geschäftsmodell für arbeitsmedizinische Betreuung')
    print(result['status'])
    print(result['milos_summary'])

asyncio.run(main())
```

Tests ohne API-Key: `python -m unittest discover -v` (6 Tests).

**Noch offen:** echter OpenAI-Agents-SDK-Livetest einschließlich `Agent.clone`, robustes globales Parallelitätslimit auch für verschachtelte Aufträge, dauerhafte Queue/Neustart-Wiederaufnahme, eine gesonderte Konflikt-/Debattenrunde und isoliertes Render-Testdeployment. Keine Änderung an produktiver `app.py`, `team.py`, `main` oder Render.
